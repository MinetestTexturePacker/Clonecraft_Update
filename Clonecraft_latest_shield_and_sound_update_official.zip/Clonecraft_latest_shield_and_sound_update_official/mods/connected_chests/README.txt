TODO:
— disallow rotating the chest with a screwdriver
