Minetest mod "Jukebox"
=======================
version: 1.0

License of source code and textures: WTFPL
-----------------------------------------
(c) Copyright BlockMen (2013)


License of music: CC0
---------------------
The authors are : (freesound.org)
-cheesepuff (song1)
-geerterig (song2)
-rap2h (song3)
-keffstay (song4)
-usedtobe (song5)
-zagi2 (song6)

This program is free software. It comes without any warranty, to
the extent permitted by applicable law. You can redistribute it
and/or modify it under the terms of the Do What The Fuck You Want
To Public License, Version 2, as published by Sam Hocevar. See
http://sam.zoy.org/wtfpl/COPYING for more details.


Using the mod:
--------------

To use the jukebox, you have to craft one. You need 8 wood and 1 diamond to craft it following way:

wood    wood    wood
wood   diamond  wood
wood    wood    wood


Furthermore you need Music Discs, that you can craft following way:


  -    coal     -
coal   gold    coal
  -    coal     -


Just click with a music disc in your hand on the jukebox and it will play a random song. To stop the music
rightclick the box again and it will drop the music disc.

