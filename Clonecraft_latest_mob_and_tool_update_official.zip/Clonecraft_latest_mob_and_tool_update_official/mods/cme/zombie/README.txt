Zombie for Creatures MOB-Engine
===============================
Copyright (c) 2015-2016 BlockMen <blockmen2015@gmail.com>

Version: 2.0 Beta


Adds zombies to Minetest (requires Creatures MOB-Engine).
Zombies can spawn to every day-time in the world as long there it is dark enough.
You will find some in caves, dark forests and ofc a lot at night.
If they notice any player near they will attack.
Zombies have 20 HP (like players) and drop rotten flesh randomly.


License: 
~~~~~~~~
Code:
(c) Copyright 2015-2016 BlockMen; modified zlib-License
see "LICENSE.txt" for details.

Media(textures and meshes/models):
(c) Copyright (2014-2016) BlockMen; CC-BY-SA 3.0

Sounds:
- creatures_zombie.1.ogg, Under7dude(https://freesound.org/people/Under7dude) CC0
- creatures_zombie.2.ogg, Under7dude(https://freesound.org/people/Under7dude) CC0
- creatures_zombie.3.ogg, Under7dude(https://freesound.org/people/Under7dude) CC0
- creatures_zombie_death.ogg, Under7dude(https://freesound.org/people/Under7dude) CC0

Github:
~~~~~~~
https://github.com/BlockMen/cme/zombie
